YAIIII APK V1

Qué hace:
- Captura partido, mercado, cuota y probabilidad real estimada.
- Calcula:
  p_imp = 1/cuota
  Edge = p_real - p_imp
  EV = p_real * cuota - 1
  Kelly fraccionado 1/4
- Incluye checklist HT PRO de 9 factores.
- Da veredicto: BET / BET DÉBIL / NO BET.

Cómo abrir:
1. Instala Android Studio.
2. Abre la carpeta YAIIII_APK_V1.
3. Espera a que Gradle sincronice.
4. Conecta tu Android o usa emulador.
5. Build > Build APK.

Notas:
- Esta V1 no consulta internet ni extrae cuotas automáticamente.
- La V2 puede agregar historial de picks, CSV/exportación y más pantallas.
- La V3 puede integrar NIMZAY y auditoría.