package com.yaiiii.app;

import android.app.Activity;
import android.os.Bundle;
import android.widget.*;

public class MainActivity extends Activity {
    EditText matchInput, marketInput, oddsInput, realProbInput;
    TextView resultText;
    CheckBox[] factors;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        matchInput = findViewById(R.id.matchInput);
        marketInput = findViewById(R.id.marketInput);
        oddsInput = findViewById(R.id.oddsInput);
        realProbInput = findViewById(R.id.realProbInput);
        resultText = findViewById(R.id.resultText);

        factors = new CheckBox[]{
            findViewById(R.id.f1), findViewById(R.id.f2), findViewById(R.id.f3),
            findViewById(R.id.f4), findViewById(R.id.f5), findViewById(R.id.f6),
            findViewById(R.id.f7), findViewById(R.id.f8), findViewById(R.id.f9)
        };

        Button calcButton = findViewById(R.id.calcButton);
        calcButton.setOnClickListener(v -> calculate());
    }

    private void calculate() {
        try {
            String match = matchInput.getText().toString();
            String market = marketInput.getText().toString();
            double odds = Double.parseDouble(oddsInput.getText().toString());
            double pReal = Double.parseDouble(realProbInput.getText().toString()) / 100.0;

            if (odds <= 1.0 || pReal <= 0 || pReal >= 1) {
                resultText.setText("Revisa datos: cuota debe ser mayor a 1.00 y probabilidad entre 1 y 99%.");
                return;
            }

            double pImp = 1.0 / odds;
            double edge = pReal - pImp;
            double ev = (pReal * odds) - 1.0;

            double b = odds - 1.0;
            double q = 1.0 - pReal;
            double kellyFull = ((b * pReal) - q) / b;
            double kellyQuarter = Math.max(0, kellyFull / 4.0);

            int htScore = 0;
            for (CheckBox cb : factors) if (cb.isChecked()) htScore++;

            String verdict;
            if (edge >= 0.05 && ev > 0 && kellyQuarter > 0) {
                verdict = "BET";
            } else if (edge >= 0.03 && ev > 0) {
                verdict = "BET DÉBIL / ESPERAR LIVE";
            } else {
                verdict = "NO BET";
            }

            String htVerdict = htScore >= 7 ? "HT PRO: candidato fuerte" :
                    htScore >= 5 ? "HT PRO: esperar / condicional" :
                    "HT PRO: no suficiente";

            String out =
                    "Partido: " + match + "\n" +
                    "Mercado: " + market + "\n\n" +
                    "Cuota: " + fmt(odds) + "\n" +
                    "p_imp: " + pct(pImp) + "\n" +
                    "p_real: " + pct(pReal) + "\n" +
                    "Edge: " + pct(edge) + "\n" +
                    "EV: " + pct(ev) + "\n" +
                    "Kelly 1/4: " + pct(kellyQuarter) + "\n\n" +
                    "Índice HT: " + htScore + "/9\n" +
                    htVerdict + "\n\n" +
                    "Veredicto YAIIII: " + verdict;

            resultText.setText(out);
        } catch (Exception e) {
            resultText.setText("Faltan datos o hay un error en la cuota/probabilidad.");
        }
    }

    private String pct(double x) {
        return String.format("%.1f%%", x * 100.0);
    }

    private String fmt(double x) {
        return String.format("%.2f", x);
    }
}